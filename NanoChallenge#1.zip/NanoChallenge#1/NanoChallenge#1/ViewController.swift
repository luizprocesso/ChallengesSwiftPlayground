//
//  ViewController.swift
//  NanoChallenge#1
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 27/11/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var numberOnScreen:Double = 0
    var previousNumber:Double = 0
    var performingMath = false
    var operation = 0
    @IBOutlet weak var display: UILabel!
    var canDot = true
    var canOpr = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func buttons(_ sender: UIButton) {
        if display.text != "" && sender.tag != 16 && sender.tag != 15 && sender.tag != 19 &&
            sender.tag != 18 && sender.tag != 20 && sender.tag != 21 && sender.tag != 22 && sender.tag != 24 && sender.tag != 25 && sender.tag != 26
        {
            if canOpr == true
            {
                previousNumber = Double(display.text!)!
            }
            if sender.tag == 11 //minus
            {
                display.text = "-"
                canOpr = false
            }
            else if sender.tag == 12 //plus
            {
                display.text = "+"
                canOpr = false
            }
            else if sender.tag == 13 //divide
            {
                display.text = "÷"
                canOpr = false
            }
            else if sender.tag == 14 //multiply
            {
                display.text = "X"
                canOpr = false
            }
            else if sender.tag == 17 //percent
            {
                display.text = "%"
                canOpr = false
            }
            else if sender.tag == 23 //power
            {
                display.text = "ˆ"
                canOpr = false
            }
            operation = sender.tag
            canDot = true
            performingMath = true;
        }
        else if sender.tag == 15 //equal
        {
            if operation == 11 //minus
            {
                display.text = String(previousNumber - numberOnScreen)
            }
            else if operation == 12 //plus
            {
                display.text = String(previousNumber + numberOnScreen)
            }
            else if operation == 13 //divide
            {
                display.text = String(previousNumber / numberOnScreen)
            }
            else if operation == 14 //multiply
            {
                display.text = String(previousNumber * numberOnScreen)
            }
            else if operation == 17 //percent
            {
                display.text = String(previousNumber / 100 * numberOnScreen)
            }
            canOpr = true
        }
        else if sender.tag == 16 // cButton
        {
            display.text = ""
            previousNumber = 0;
            numberOnScreen = 0;
            operation = 0;
            canDot = true
            canOpr = true
        }
        else if sender.tag == 19 // plusminusButton
        {
            display.text = String(numberOnScreen * -1)
            numberOnScreen = Double(display.text!)!
        }
        else if sender.tag == 18 // commaButton
        {
            if (canDot == true && display.text != "")
            {
                display.text = display.text! + String(".")
                numberOnScreen = Double(display.text!)!
                canDot = false
            }
            if (canDot == true && display.text == "")
            {
                display.text = "0"
                display.text = display.text! + String(".")
                numberOnScreen = Double(display.text!)!
                canDot = false
            }
        }
        
        
    }
    @IBAction func numbers(_ sender: UIButton) {
                if performingMath == true {
            display.text = String(sender.tag-1)
            numberOnScreen = Double(display.text!)!
            performingMath = false
                } else {
                    display.text = display.text! + String(sender.tag-1)
                    numberOnScreen = Double(display.text!)!
        }

    }
        
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}


