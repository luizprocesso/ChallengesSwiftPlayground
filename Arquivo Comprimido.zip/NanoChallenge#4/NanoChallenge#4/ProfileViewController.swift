//
//  ProfileViewController.swift
//  NanoChallenge#4
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 30/11/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    @IBOutlet weak var contactImage: UIImageView!
    var contact:Contact? // this var will receive from tableView [selectedContact]
    
    
    @IBOutlet weak var nameLabel: UILabel!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        contactImage.image = contact?.picture
        nameLabel.text = contact?.name
       
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
