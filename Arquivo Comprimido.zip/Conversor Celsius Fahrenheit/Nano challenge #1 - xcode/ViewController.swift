//
//  ViewController.swift
//  Nano challenge #1 - xcode
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 27/11/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fahrenheitLabel: UILabel!
    @IBOutlet weak var celsiusTextFiled: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func convertToFahrenheit(_ sender: Any) {
    let celsius = Double(celsiusTextFiled.text!)
        let fahrenheit = (9.0*celsius!)/5+32
        
        fahrenheitLabel.text = String(fahrenheit)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

