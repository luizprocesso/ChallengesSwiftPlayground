import UIKit
import PlaygroundSupport

let textView = UITextView()
textView.text = "Hello World!\nHello Playground!"


PlaygroundPage.current.liveView = textView
