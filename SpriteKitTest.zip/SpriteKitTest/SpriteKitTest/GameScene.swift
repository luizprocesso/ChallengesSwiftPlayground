//
//  GameScene.swift
//  SpriteKitTest
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 04/12/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var label:SKLabelNode!
    //var previousTime:TimeInterval!
    //var firstTime = true
    var sprite:SKSpriteNode!
    var atlas:SKTextureAtlas!
    
    
    
    
    
    
    //private var label : SKLabelNode?
    //private var spinnyNode : SKShapeNode?
    
    override func didMove(to view: SKView) {
        scaleMode = .aspectFit
        backgroundColor = #colorLiteral(red: 1, green: 0.5763723254, blue: 0, alpha: 1)
        size = CGSize(width: 720, height: 1280)
        
        label = SKLabelNode(text:"Merhaba Herkez")
        addChild(label)
        label.fontColor = #colorLiteral(red: 0.1294117719, green: 0.2156862766, blue: 0.06666667014, alpha: 1)
        label.position = CGPoint(x: size.width/2, y: -100)
        label.fontSize = 72
        label.zPosition = 1
        
        atlas = SKTextureAtlas.init(named: "Imagens")
        
        
        let action = SKAction.repeatForever(SKAction.move(by: CGVector.init(dx: 0, dy: 60), duration: 1))
        label.run(action)
        
        let texture = SKTexture.init(imageNamed: "zeus")
        sprite = SKSpriteNode.init(texture:texture)
        addChild(sprite)
        sprite.position = CGPoint(x: 360, y: 640)
        sprite.size = CGSize(width: 250, height: 250)
        
        let spriteList = [atlas.textureNamed("Ronda"),atlas.textureNamed("zeus") ]
        
        let spriteAction = SKAction.animate(with: spriteList, timePerFrame: 0.5)
        
    sprite.run(SKAction.repeatForever(spriteAction))
        
        
        
    }
    
    
    
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        /*let deltaTime:CGFloat!
        previousTime = currentTime
        
        if firstTime{
        
        firstTime = false
        deltaTime = 1/60
        
        }else{
        deltaTime = CGFloat(currentTime-previousTime)
        
        }
        
        label.position.y += deltaTime*60*/
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches{
            let pos = touch.location(in: self)
            
            let touchSprite = SKSpriteNode(texture: atlas.textureNamed("zeus"))
            addChild(touchSprite)
            touchSprite.position = pos
            
            if nodes(at:pos).contains(sprite){
                touchSprite.color = #colorLiteral(red: 0.2588235438, green: 0.7568627596, blue: 0.9686274529, alpha: 1)
                touchSprite.colorBlendFactor = 1
                touchSprite.zPosition = 2
            }
            
            let action = SKAction.fadeOut(withDuration: 2)
            touchSprite.run(action, completion: {touchSprite.removeFromParent()})
            
        
        
        
        
        
        
        
        
        
        }
    }
}
