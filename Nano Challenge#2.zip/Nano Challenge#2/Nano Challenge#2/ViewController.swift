//
//  ViewController.swift
//  Nano Challenge#2
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 28/11/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var dice4: UILabel!
    @IBOutlet weak var dice6: UILabel!
    @IBOutlet weak var dice8: UILabel!
    @IBOutlet weak var dice10: UILabel!
    @IBOutlet weak var dice12: UILabel!
    @IBOutlet weak var dice20: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func dice4(_ sender: UIButton) {
        let RdmD4 = Int(arc4random_uniform(4)+1)
        dice4.text = String(RdmD4)
    }

    @IBAction func dice6(_ sender: UIButton) {
        let RdmD6 = Int(arc4random_uniform(6)+1)
        dice6.text = String(RdmD6)
    }
    @IBAction func dice8(_ sender: UIButton) {
        let RdmD8 = Int(arc4random_uniform(8)+1)
        dice8.text = String(RdmD8)
    }
    
    @IBAction func dice10(_ sender: UIButton) {
        let RdmD10 = Int(arc4random_uniform(10)+1)
        dice10.text = String(RdmD10)
    }
    
    @IBAction func dice12(_ sender: UIButton) {
        let RdmD12 = Int(arc4random_uniform(12)+1)
        dice12.text = String(RdmD12)
    }
    
    @IBAction func dice20(_ sender: UIButton) {
        let RdmD20 = Int(arc4random_uniform(20)+1)
        dice20.text = String(RdmD20)
    }
    
    
    @IBAction func rollAll(_ sender: UIButton) {
        
        let RdmD4 = Int(arc4random_uniform(4)+1)
        let RdmD8 = Int(arc4random_uniform(8)+1)
        let RdmD6 = Int(arc4random_uniform(6)+1)
        let RdmD10 = Int(arc4random_uniform(10)+1)
        let RdmD12 = Int(arc4random_uniform(12)+1)
        let RdmD20 = Int(arc4random_uniform(20)+1)
        
        dice4.text = String(RdmD4)
        dice6.text = String(RdmD6)
        dice8.text = String(RdmD8)
        dice10.text = String(RdmD10)
        dice12.text = String(RdmD12)
        dice20.text = String(RdmD20)
    }
    
    
    @IBAction func clear(_ sender: UIButton) {
        
        dice4.text = ""
        dice6.text = ""
        dice8.text = ""
        dice10.text = ""
        dice12.text = ""
        dice20.text = ""
    }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

