//
//  contact.swift
//  NanoChallenge#4
//
//  Created by LUIZ OTAVIO MORAES PROCESSO JUNIOR on 30/11/17.
//  Copyright © 2017 LUIZ OTAVIO MORAES PROCESSO JUNIOR. All rights reserved.
//

import Foundation
import UIKit


//contact Model

class Contact{
    var name: String?
    var lastName: String?
    var picture: UIImage?
    var eMail: String?
    var phoneNumber: Int?
    
    
}
